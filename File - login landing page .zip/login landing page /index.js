
// Get the input fields and button
const usernameInput = document.querySelector('input[type="text"]');
const passwordInput = document.querySelector('input[type="password"]');
const submitButton = document.querySelector('.js-button');
const forgetPasswordLink = document.querySelector('.group a:first-child');
const signUpLink = document.querySelector('.group a:last-child');

// Add event listener to submit button
submitButton.addEventListener('click', (e) => {
  e.preventDefault();
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();

  // Validate input fields
  if (username === '' || password === '') {
    alert('Please fill in both username and password fields.');
    return;
  }

  // Send a POST request to the server (replace with your actual API endpoint)
  fetch('/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, password }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
      //   Login successful, redirect to dashboard or home page
        window.location.href = '/dashboard';
      } else {
        alert('Invalid username or password.');
      }
    })
    .catch((error) => {
      console.error('Error:', error);
      alert('You have successfully ✅');
    });
});

// Add event listener to forget password link
forgetPasswordLink.addEventListener('click', (e) => {
  e.preventDefault();
  // Open a modal or redirect to forget password page
  alert('Forget password feature coming soon!');
});

// Add event listener to sign up link
signUpLink.addEventListener('click', (e) => {
  e.preventDefault();
  // Redirect to sign up page
  window.location.href = '/signup';
});

// Add animation to input fields
usernameInput.addEventListener('focus', () => {
  usernameInput.style.borderColor = '#aaa';
  usernameInput.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.1)';
});

usernameInput.addEventListener('blur', () => {
  usernameInput.style.borderColor = '#ccc';
  usernameInput.style.boxShadow = 'none';
});

passwordInput.addEventListener('focus', () => {
  passwordInput.style.borderColor = '#aaa';
  passwordInput.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.1)';
});

passwordInput.addEventListener('blur', () => {
  passwordInput.style.borderColor = '#ccc';
  passwordInput.style.boxShadow = 'none';
});


